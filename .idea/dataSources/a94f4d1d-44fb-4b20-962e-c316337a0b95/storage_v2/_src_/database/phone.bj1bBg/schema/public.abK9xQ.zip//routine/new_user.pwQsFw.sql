create procedure new_user(IN name character varying, IN phone character varying)
    language plpgsql
as
$$
BEGIN
    IF EXISTS(SELECT 1 FROM phonebook WHERE first_name=name) THEN
        UPDATE phonebook SET phone_num=phone WHERE first_name=name;
    ELSE
        INSERT INTO phonebook(first_name, phone_num) VALUES(name,phone);

    end if;
END;
$$;

alter procedure new_user(varchar, varchar) owner to postgres;

