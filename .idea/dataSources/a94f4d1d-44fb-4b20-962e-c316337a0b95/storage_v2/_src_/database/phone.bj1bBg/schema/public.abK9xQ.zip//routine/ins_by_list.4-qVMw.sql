create function ins_by_list(my_list text[]) returns void
    language plpgsql
as
$$
DECLARE
    l INTEGER;
BEGIN
    l=length(my_list);
    FOR i in 1..l
        LOOP
            INSERT INTO phonebook(first_name, phone_num) VALUES (my_list[i][0] ,my_list[i][1]);
        END LOOP;
END;
$$;

alter function ins_by_list(text[]) owner to postgres;

