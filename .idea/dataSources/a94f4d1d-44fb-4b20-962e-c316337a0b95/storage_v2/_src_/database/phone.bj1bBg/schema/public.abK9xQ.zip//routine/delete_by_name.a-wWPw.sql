create procedure delete_by_name(IN name character varying)
    language plpgsql
as
$$
BEGIN
    DELETE
    FROM phonebook p
    where p.first_name = $1;
END;
$$;

alter procedure delete_by_name(varchar) owner to postgres;

