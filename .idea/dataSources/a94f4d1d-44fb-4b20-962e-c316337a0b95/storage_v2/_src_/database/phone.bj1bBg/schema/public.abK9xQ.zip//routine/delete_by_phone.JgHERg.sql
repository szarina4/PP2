create procedure delete_by_phone(IN phone character varying)
    language plpgsql
as
$$
BEGIN
    DELETE
    FROM phonebook p
    where p.phone_num = $1;
END;
$$;

alter procedure delete_by_phone(varchar) owner to postgres;

