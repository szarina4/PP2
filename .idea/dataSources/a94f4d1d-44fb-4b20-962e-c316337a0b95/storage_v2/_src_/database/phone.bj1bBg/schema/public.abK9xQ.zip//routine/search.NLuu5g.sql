create function search(p_pattern character varying)
    returns TABLE(first_name character varying, phone_num character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT
        phonebook.first_name,
        phonebook.phone_num
    FROM
        phonebook
    WHERE
        phonebook.first_name ILIKE p_pattern ;
END;
$$;

alter function search(varchar) owner to postgres;

